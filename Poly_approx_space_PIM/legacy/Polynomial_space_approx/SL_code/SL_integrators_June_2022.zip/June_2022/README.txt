Matlab codes written by SL, 13/6/22, based on example codes provided by OP.

Hankel_midpt.m = midpt rule to integrate Hankel function
Hankel_midpt_PIM.m = Product Integration Midpt rule, for same function
m1_tilde, m2, smoothing_fun, v1_weights_mid -> function files for PIM
test_code.m - code to run test results
  . One example tested, 13/6/22, seems convincing.
  . Would be sensible to test for more examples before rolling code out.

Meeting_SL_OP_130622.pdf - handwritten notes from meeting (view using 2-page mode) 